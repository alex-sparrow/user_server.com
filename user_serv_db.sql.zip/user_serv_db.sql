-- phpMyAdmin SQL Dump
-- version 4.2.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 08, 2014 at 02:35 PM
-- Server version: 5.5.38-0ubuntu0.12.04.1
-- PHP Version: 5.3.10-1ubuntu3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `user_serv_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_markers`
--

CREATE TABLE IF NOT EXISTS `tbl_markers` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `latlng` text NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_markers`
--

INSERT INTO `tbl_markers` (`id`, `user_id`, `latlng`, `name`) VALUES
(5, 4, 'a:2:{s:3:"lat";s:4:"37.5";s:3:"lng";s:6:"43.231";}', 'm_1'),
(6, 4, 'a:2:{s:3:"lat";s:4:"37.5";s:3:"lng";s:6:"43.231";}', 'm_2'),
(8, 4, 'a:2:{s:3:"lat";s:4:"37.5";s:3:"lng";s:2:"41";}', 'm_3'),
(9, 4, 'a:2:{s:3:"lat";s:4:"37.5";s:3:"lng";s:2:"41";}', 'm_4'),
(10, 4, 'a:2:{s:3:"lat";s:2:"11";s:3:"lng";s:2:"41";}', 'm_5');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_session_id`
--

CREATE TABLE IF NOT EXISTS `tbl_session_id` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_key` varchar(255) NOT NULL,
  `exp_date` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_session_id`
--

INSERT INTO `tbl_session_id` (`id`, `user_id`, `session_key`, `exp_date`) VALUES
(1, 4, '47f00f10a93d9e77099e12435a761fa570df9607fb8607fdd23b6f2bdf5b02f3', 1411809782);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE IF NOT EXISTS `tbl_users` (
`id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `login`, `password`, `fname`, `lname`) VALUES
(4, 'alex@mail.ru', 'fcea920f7412b5da7be0cf42b8c93759', 'alex', 'hint');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_markers`
--
ALTER TABLE `tbl_markers`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `tbl_session_id`
--
ALTER TABLE `tbl_session_id`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_markers`
--
ALTER TABLE `tbl_markers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tbl_session_id`
--
ALTER TABLE `tbl_session_id`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
